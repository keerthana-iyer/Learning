```python
# Data Handling
import pandas as pd
import numpy as np

# Visualization
import matplotlib.pyplot as plt
import seaborn as sns

# Statistics
from scipy import stats
from scipy.stats import shapiro, levene, ttest_ind

df=pd.read_csv(r'C:\Users\keert\Downloads\medical-charges.csv')

df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>age</th>
      <th>sex</th>
      <th>bmi</th>
      <th>children</th>
      <th>smoker</th>
      <th>region</th>
      <th>charges</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>19</td>
      <td>female</td>
      <td>27.900</td>
      <td>0</td>
      <td>yes</td>
      <td>southwest</td>
      <td>16884.92400</td>
    </tr>
    <tr>
      <th>1</th>
      <td>18</td>
      <td>male</td>
      <td>33.770</td>
      <td>1</td>
      <td>no</td>
      <td>southeast</td>
      <td>1725.55230</td>
    </tr>
    <tr>
      <th>2</th>
      <td>28</td>
      <td>male</td>
      <td>33.000</td>
      <td>3</td>
      <td>no</td>
      <td>southeast</td>
      <td>4449.46200</td>
    </tr>
    <tr>
      <th>3</th>
      <td>33</td>
      <td>male</td>
      <td>22.705</td>
      <td>0</td>
      <td>no</td>
      <td>northwest</td>
      <td>21984.47061</td>
    </tr>
    <tr>
      <th>4</th>
      <td>32</td>
      <td>male</td>
      <td>28.880</td>
      <td>0</td>
      <td>no</td>
      <td>northwest</td>
      <td>3866.85520</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 1338 entries, 0 to 1337
    Data columns (total 7 columns):
     #   Column    Non-Null Count  Dtype  
    ---  ------    --------------  -----  
     0   age       1338 non-null   int64  
     1   sex       1338 non-null   object 
     2   bmi       1338 non-null   float64
     3   children  1338 non-null   int64  
     4   smoker    1338 non-null   object 
     5   region    1338 non-null   object 
     6   charges   1338 non-null   float64
    dtypes: float64(2), int64(2), object(3)
    memory usage: 73.3+ KB
    


```python
df.shape
```




    (1338, 7)




```python
df.describe(include='all')
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>age</th>
      <th>sex</th>
      <th>bmi</th>
      <th>children</th>
      <th>smoker</th>
      <th>region</th>
      <th>charges</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>1338.000000</td>
      <td>1338</td>
      <td>1338.000000</td>
      <td>1338.000000</td>
      <td>1338</td>
      <td>1338</td>
      <td>1338.000000</td>
    </tr>
    <tr>
      <th>unique</th>
      <td>NaN</td>
      <td>2</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2</td>
      <td>4</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>top</th>
      <td>NaN</td>
      <td>male</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>no</td>
      <td>southeast</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>freq</th>
      <td>NaN</td>
      <td>676</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1064</td>
      <td>364</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>39.207025</td>
      <td>NaN</td>
      <td>30.663397</td>
      <td>1.094918</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>13270.422265</td>
    </tr>
    <tr>
      <th>std</th>
      <td>14.049960</td>
      <td>NaN</td>
      <td>6.098187</td>
      <td>1.205493</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>12110.011237</td>
    </tr>
    <tr>
      <th>min</th>
      <td>18.000000</td>
      <td>NaN</td>
      <td>15.960000</td>
      <td>0.000000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1121.873900</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>27.000000</td>
      <td>NaN</td>
      <td>26.296250</td>
      <td>0.000000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>4740.287150</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>39.000000</td>
      <td>NaN</td>
      <td>30.400000</td>
      <td>1.000000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>9382.033000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>51.000000</td>
      <td>NaN</td>
      <td>34.693750</td>
      <td>2.000000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>16639.912515</td>
    </tr>
    <tr>
      <th>max</th>
      <td>64.000000</td>
      <td>NaN</td>
      <td>53.130000</td>
      <td>5.000000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>63770.428010</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.isnull().sum()
```




    age         0
    sex         0
    bmi         0
    children    0
    smoker      0
    region      0
    charges     0
    dtype: int64




```python
((df.isnull().sum())/len(df))*100
```




    age         0.0
    sex         0.0
    bmi         0.0
    children    0.0
    smoker      0.0
    region      0.0
    charges     0.0
    dtype: float64




```python
df.isnull().sum().sum()
```




    np.int64(0)




```python
df.duplicated().sum()
```




    np.int64(1)




```python
df[df.duplicated(keep=False)]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>age</th>
      <th>sex</th>
      <th>bmi</th>
      <th>children</th>
      <th>smoker</th>
      <th>region</th>
      <th>charges</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>195</th>
      <td>19</td>
      <td>male</td>
      <td>30.59</td>
      <td>0</td>
      <td>no</td>
      <td>northwest</td>
      <td>1639.5631</td>
    </tr>
    <tr>
      <th>581</th>
      <td>19</td>
      <td>male</td>
      <td>30.59</td>
      <td>0</td>
      <td>no</td>
      <td>northwest</td>
      <td>1639.5631</td>
    </tr>
  </tbody>
</table>
</div>




```python
df=df.drop_duplicates(keep='first')
```


```python
df.shape
```




    (1337, 7)




```python
for col in df.select_dtypes(include='object').columns:
    print(col,':',df[col].unique())
```

    sex : ['female' 'male']
    smoker : ['yes' 'no']
    region : ['southwest' 'southeast' 'northwest' 'northeast']
    


```python
for col in df.select_dtypes(include='object').columns:
    print(col,':',df[col].value_counts())
```

    sex : sex
    male      675
    female    662
    Name: count, dtype: int64
    smoker : smoker
    no     1063
    yes     274
    Name: count, dtype: int64
    region : region
    southeast    364
    southwest    325
    northwest    324
    northeast    324
    Name: count, dtype: int64
    

## Hypothesis Testing

The following statistical tests are performed:

- **Shapiro-Wilk Test** – Tests the normality assumption.
- **Levene's Test** – Tests the equality of variances.
- **Independent Two-Sample t-test** – Determines whether the mean insurance charges differ significantly between smokers and non-smokers.


```python
smoker_charges = df[df['smoker'] == 'yes']['charges']
nonsmoker_charges = df[df['smoker'] == 'no']['charges']
```


```python
from scipy.stats import shapiro, levene, ttest_ind

# 1. Normality check
stat1, p1 = shapiro(smoker_charges)
stat2, p2 = shapiro(nonsmoker_charges)
print('Smoker group normality p-value:', p1)
print('Non-smoker group normality p-value:', p2)

# 2. Equal variance check
lev_stat, lev_p = levene(smoker_charges, nonsmoker_charges)
print('Levene p-value:', lev_p)


```

    Smoker group normality p-value: 3.6249900590074277e-09
    Non-smoker group normality p-value: 1.5035032808411558e-28
    Levene p-value: 1.670117565125241e-66
    


```python
import matplotlib.pyplot as plt
import seaborn as sns

# Create figure with two subplots
fig, axes = plt.subplots(1, 2)

# Histogram + KDE for smokers
sns.histplot(smoker_charges,kde=True,ax=axes[0])
axes[0].set_title("Distribution of Insurance Charges (Smokers)")
axes[0].set_xlabel("Insurance Charges")
axes[0].set_ylabel("Frequency")

# Histogram + KDE for non-smokers
sns.histplot(nonsmoker_charges, kde=True, ax=axes[1])
axes[1].set_title("Distribution of Insurance Charges (Non-Smokers)")
axes[1].set_xlabel("Insurance Charges")
axes[1].set_ylabel("Frequency")

plt.tight_layout()
plt.show()
```


    
![png](output_16_0.png)
    



```python
from scipy import stats
import matplotlib.pyplot as plt

# Create figure with two subplots
fig, axes = plt.subplots(1, 2, figsize=(14, 6))

# Q-Q plot for smokers
stats.probplot(smoker_charges, dist="norm", plot=axes[0])
axes[0].set_title("Q-Q Plot: Smoker Insurance Charges")

# Q-Q plot for non-smokers
stats.probplot(nonsmoker_charges, dist="norm", plot=axes[1])
axes[1].set_title("Q-Q Plot: Non-Smoker Insurance Charges")


```




    Text(0.5, 1.0, 'Q-Q Plot: Non-Smoker Insurance Charges')




    
![png](output_17_1.png)
    



```python
# 3. t-test (using equal_var based on Levene's result)
equal_var_flag = lev_p >= 0.05   # True if variances are equal, False if not
t_stat, p_value = ttest_ind(smoker_charges, nonsmoker_charges, equal_var=equal_var_flag,alternative='greater')
print('t-statistic:', t_stat)
print('p-value:', p_value)
print('Used equal_var =', equal_var_flag)
```

    t-statistic: 32.7423097372529
    p-value: 3.1308603873638155e-103
    Used equal_var = False
    


```python
plt.figure(figsize=(10,6))
sns.boxplot(data=df,x='region',y='charges',hue='region',palette='Pastel1',legend=False,showmeans=True)
plt.title("Insurance Charges Across Regions")
plt.xlabel("Region")
plt.ylabel("Insurance Charges")
```




    Text(0, 0.5, 'Insurance Charges')




    
![png](output_19_1.png)
    



```python

```


```python
northeast=df[df['region']=='northeast']['charges']
northwest=df[df['region']=='northwest']['charges']
southeast=df[df['region']=='southeast']['charges']
southwest=df[df['region']=='southwest']['charges']


```


```python
alpha=0.05
region={
     "Northeast": northeast,
    "Northwest": northwest,
    "Southeast": southeast,
    "Southwest": southwest
    }
for region,values in region.items():
    stat,p=shapiro(values)
    print(f"{region}")
    print(f"p-value:{p:.4e}")
```

    Northeast
    p-value:6.5524e-18
    Northwest
    p-value:4.6607e-19
    Southeast
    p-value:1.2326e-19
    Southwest
    p-value:2.0238e-20
    


```python
# Create figure with two subplots
fig, axes = plt.subplots(2, 2)
axes=axes.flatten()
# Histogram + KDE for smokers
sns.histplot(northeast,kde=True,ax=axes[0])
axes[0].set_title("Distribution of NorthEast Charges")
axes[0].set_xlabel("Insurance Charges")
axes[0].set_ylabel("Frequency")

# Histogram + KDE for non-smokers
sns.histplot(northwest, kde=True, ax=axes[1])
axes[1].set_title("Distribution of NorthWest Charges")
axes[1].set_xlabel("Insurance Charges")
axes[1].set_ylabel("Frequency")



sns.histplot(southeast,kde=True,ax=axes[2])
axes[2].set_title("Distribution of SouthEast Charges")
axes[2].set_xlabel("Insurance Charges")
axes[2].set_ylabel("Frequency")

# Histogram + KDE for non-smokers
sns.histplot(southwest, kde=True, ax=axes[3])
axes[3].set_title("Distribution of SouthWest Charges")
axes[3].set_xlabel("Insurance Charges")
axes[3].set_ylabel("Frequency")

plt.tight_layout()
plt.show()
```


    
![png](output_23_0.png)
    



```python
# Create figure with two subplots
fig, axes = plt.subplots(2, 2, figsize=(12, 10))
axes=axes.flatten()

# Q-Q plot for smokers
stats.probplot(northeast, dist="norm", plot=axes[0])
axes[0].set_title("Q-Q Plot: NorthEast")

# Q-Q plot for non-smokers
stats.probplot(northwest, dist="norm", plot=axes[1])
axes[1].set_title("Q-Q Plot: NorthWest")

stats.probplot(southeast, dist="norm", plot=axes[2])
axes[2].set_title("Q-Q Plot: Southeast")

# Q-Q plot for non-smokers
stats.probplot(southwest, dist="norm", plot=axes[3])
axes[3].set_title("Q-Q Plot: Southwest")

```




    Text(0.5, 1.0, 'Q-Q Plot: Southwest')




    
![png](output_24_1.png)
    



```python
lev_stat, lev_p = levene(
    northeast,
    northwest,
    southeast,
    southwest
)


print("p-value:", lev_p)
```

    p-value: 0.0008689544824002284
    


```python
from scipy.stats import f_oneway
equal_var_flag = bool(lev_p >= 0.05)
print(equal_var_flag)

```

    False
    


```python
f_stat,p_value=f_oneway(northeast,northwest,southeast,southwest,equal_var=equal_var_flag)
print(p_value)
```

    0.05348899434656477
    


```python
x=df.drop(columns='charges')
y=df['charges']
x['sex']=x['sex'].map({'female':0,'male':1})
x['smoker']=x['smoker'].map({'yes':1,'no':0})
x.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>age</th>
      <th>sex</th>
      <th>bmi</th>
      <th>children</th>
      <th>smoker</th>
      <th>region</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>19</td>
      <td>0</td>
      <td>27.900</td>
      <td>0</td>
      <td>1</td>
      <td>southwest</td>
    </tr>
    <tr>
      <th>1</th>
      <td>18</td>
      <td>1</td>
      <td>33.770</td>
      <td>1</td>
      <td>0</td>
      <td>southeast</td>
    </tr>
    <tr>
      <th>2</th>
      <td>28</td>
      <td>1</td>
      <td>33.000</td>
      <td>3</td>
      <td>0</td>
      <td>southeast</td>
    </tr>
    <tr>
      <th>3</th>
      <td>33</td>
      <td>1</td>
      <td>22.705</td>
      <td>0</td>
      <td>0</td>
      <td>northwest</td>
    </tr>
    <tr>
      <th>4</th>
      <td>32</td>
      <td>1</td>
      <td>28.880</td>
      <td>0</td>
      <td>0</td>
      <td>northwest</td>
    </tr>
  </tbody>
</table>
</div>




```python
#one hot encode
x=pd.get_dummies(x,columns=['region'],drop_first=True,dtype=int)
x.columns
```




    Index(['age', 'sex', 'bmi', 'children', 'smoker', 'region_northwest',
           'region_southeast', 'region_southwest'],
          dtype='object')




```python
from sklearn.model_selection import train_test_split

x_train,x_test, y_train, y_test = train_test_split(
    x,
    y,
    test_size=0.2,
    random_state=42
)
```


```python
from sklearn.linear_model import LinearRegression
lr=LinearRegression()
lr.fit(x_train,y_train)
```




<style>#sk-container-id-1 {
  /* Definition of color scheme common for light and dark mode */
  --sklearn-color-text: #000;
  --sklearn-color-text-muted: #666;
  --sklearn-color-line: gray;
  /* Definition of color scheme for unfitted estimators */
  --sklearn-color-unfitted-level-0: #fff5e6;
  --sklearn-color-unfitted-level-1: #f6e4d2;
  --sklearn-color-unfitted-level-2: #ffe0b3;
  --sklearn-color-unfitted-level-3: chocolate;
  /* Definition of color scheme for fitted estimators */
  --sklearn-color-fitted-level-0: #f0f8ff;
  --sklearn-color-fitted-level-1: #d4ebff;
  --sklearn-color-fitted-level-2: #b3dbfd;
  --sklearn-color-fitted-level-3: cornflowerblue;

  /* Specific color for light theme */
  --sklearn-color-text-on-default-background: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, black)));
  --sklearn-color-background: var(--sg-background-color, var(--theme-background, var(--jp-layout-color0, white)));
  --sklearn-color-border-box: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, black)));
  --sklearn-color-icon: #696969;

  @media (prefers-color-scheme: dark) {
    /* Redefinition of color scheme for dark theme */
    --sklearn-color-text-on-default-background: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, white)));
    --sklearn-color-background: var(--sg-background-color, var(--theme-background, var(--jp-layout-color0, #111)));
    --sklearn-color-border-box: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, white)));
    --sklearn-color-icon: #878787;
  }
}

#sk-container-id-1 {
  color: var(--sklearn-color-text);
}

#sk-container-id-1 pre {
  padding: 0;
}

#sk-container-id-1 input.sk-hidden--visually {
  border: 0;
  clip: rect(1px 1px 1px 1px);
  clip: rect(1px, 1px, 1px, 1px);
  height: 1px;
  margin: -1px;
  overflow: hidden;
  padding: 0;
  position: absolute;
  width: 1px;
}

#sk-container-id-1 div.sk-dashed-wrapped {
  border: 1px dashed var(--sklearn-color-line);
  margin: 0 0.4em 0.5em 0.4em;
  box-sizing: border-box;
  padding-bottom: 0.4em;
  background-color: var(--sklearn-color-background);
}

#sk-container-id-1 div.sk-container {
  /* jupyter's `normalize.less` sets `[hidden] { display: none; }`
     but bootstrap.min.css set `[hidden] { display: none !important; }`
     so we also need the `!important` here to be able to override the
     default hidden behavior on the sphinx rendered scikit-learn.org.
     See: https://github.com/scikit-learn/scikit-learn/issues/21755 */
  display: inline-block !important;
  position: relative;
}

#sk-container-id-1 div.sk-text-repr-fallback {
  display: none;
}

div.sk-parallel-item,
div.sk-serial,
div.sk-item {
  /* draw centered vertical line to link estimators */
  background-image: linear-gradient(var(--sklearn-color-text-on-default-background), var(--sklearn-color-text-on-default-background));
  background-size: 2px 100%;
  background-repeat: no-repeat;
  background-position: center center;
}

/* Parallel-specific style estimator block */

#sk-container-id-1 div.sk-parallel-item::after {
  content: "";
  width: 100%;
  border-bottom: 2px solid var(--sklearn-color-text-on-default-background);
  flex-grow: 1;
}

#sk-container-id-1 div.sk-parallel {
  display: flex;
  align-items: stretch;
  justify-content: center;
  background-color: var(--sklearn-color-background);
  position: relative;
}

#sk-container-id-1 div.sk-parallel-item {
  display: flex;
  flex-direction: column;
}

#sk-container-id-1 div.sk-parallel-item:first-child::after {
  align-self: flex-end;
  width: 50%;
}

#sk-container-id-1 div.sk-parallel-item:last-child::after {
  align-self: flex-start;
  width: 50%;
}

#sk-container-id-1 div.sk-parallel-item:only-child::after {
  width: 0;
}

/* Serial-specific style estimator block */

#sk-container-id-1 div.sk-serial {
  display: flex;
  flex-direction: column;
  align-items: center;
  background-color: var(--sklearn-color-background);
  padding-right: 1em;
  padding-left: 1em;
}


/* Toggleable style: style used for estimator/Pipeline/ColumnTransformer box that is
clickable and can be expanded/collapsed.
- Pipeline and ColumnTransformer use this feature and define the default style
- Estimators will overwrite some part of the style using the `sk-estimator` class
*/

/* Pipeline and ColumnTransformer style (default) */

#sk-container-id-1 div.sk-toggleable {
  /* Default theme specific background. It is overwritten whether we have a
  specific estimator or a Pipeline/ColumnTransformer */
  background-color: var(--sklearn-color-background);
}

/* Toggleable label */
#sk-container-id-1 label.sk-toggleable__label {
  cursor: pointer;
  display: flex;
  width: 100%;
  margin-bottom: 0;
  padding: 0.5em;
  box-sizing: border-box;
  text-align: center;
  align-items: start;
  justify-content: space-between;
  gap: 0.5em;
}

#sk-container-id-1 label.sk-toggleable__label .caption {
  font-size: 0.6rem;
  font-weight: lighter;
  color: var(--sklearn-color-text-muted);
}

#sk-container-id-1 label.sk-toggleable__label-arrow:before {
  /* Arrow on the left of the label */
  content: "▸";
  float: left;
  margin-right: 0.25em;
  color: var(--sklearn-color-icon);
}

#sk-container-id-1 label.sk-toggleable__label-arrow:hover:before {
  color: var(--sklearn-color-text);
}

/* Toggleable content - dropdown */

#sk-container-id-1 div.sk-toggleable__content {
  display: none;
  text-align: left;
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-0);
}

#sk-container-id-1 div.sk-toggleable__content.fitted {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-0);
}

#sk-container-id-1 div.sk-toggleable__content pre {
  margin: 0.2em;
  border-radius: 0.25em;
  color: var(--sklearn-color-text);
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-0);
}

#sk-container-id-1 div.sk-toggleable__content.fitted pre {
  /* unfitted */
  background-color: var(--sklearn-color-fitted-level-0);
}

#sk-container-id-1 input.sk-toggleable__control:checked~div.sk-toggleable__content {
  /* Expand drop-down */
  display: block;
  width: 100%;
  overflow: visible;
}

#sk-container-id-1 input.sk-toggleable__control:checked~label.sk-toggleable__label-arrow:before {
  content: "▾";
}

/* Pipeline/ColumnTransformer-specific style */

#sk-container-id-1 div.sk-label input.sk-toggleable__control:checked~label.sk-toggleable__label {
  color: var(--sklearn-color-text);
  background-color: var(--sklearn-color-unfitted-level-2);
}

#sk-container-id-1 div.sk-label.fitted input.sk-toggleable__control:checked~label.sk-toggleable__label {
  background-color: var(--sklearn-color-fitted-level-2);
}

/* Estimator-specific style */

/* Colorize estimator box */
#sk-container-id-1 div.sk-estimator input.sk-toggleable__control:checked~label.sk-toggleable__label {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-2);
}

#sk-container-id-1 div.sk-estimator.fitted input.sk-toggleable__control:checked~label.sk-toggleable__label {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-2);
}

#sk-container-id-1 div.sk-label label.sk-toggleable__label,
#sk-container-id-1 div.sk-label label {
  /* The background is the default theme color */
  color: var(--sklearn-color-text-on-default-background);
}

/* On hover, darken the color of the background */
#sk-container-id-1 div.sk-label:hover label.sk-toggleable__label {
  color: var(--sklearn-color-text);
  background-color: var(--sklearn-color-unfitted-level-2);
}

/* Label box, darken color on hover, fitted */
#sk-container-id-1 div.sk-label.fitted:hover label.sk-toggleable__label.fitted {
  color: var(--sklearn-color-text);
  background-color: var(--sklearn-color-fitted-level-2);
}

/* Estimator label */

#sk-container-id-1 div.sk-label label {
  font-family: monospace;
  font-weight: bold;
  display: inline-block;
  line-height: 1.2em;
}

#sk-container-id-1 div.sk-label-container {
  text-align: center;
}

/* Estimator-specific */
#sk-container-id-1 div.sk-estimator {
  font-family: monospace;
  border: 1px dotted var(--sklearn-color-border-box);
  border-radius: 0.25em;
  box-sizing: border-box;
  margin-bottom: 0.5em;
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-0);
}

#sk-container-id-1 div.sk-estimator.fitted {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-0);
}

/* on hover */
#sk-container-id-1 div.sk-estimator:hover {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-2);
}

#sk-container-id-1 div.sk-estimator.fitted:hover {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-2);
}

/* Specification for estimator info (e.g. "i" and "?") */

/* Common style for "i" and "?" */

.sk-estimator-doc-link,
a:link.sk-estimator-doc-link,
a:visited.sk-estimator-doc-link {
  float: right;
  font-size: smaller;
  line-height: 1em;
  font-family: monospace;
  background-color: var(--sklearn-color-background);
  border-radius: 1em;
  height: 1em;
  width: 1em;
  text-decoration: none !important;
  margin-left: 0.5em;
  text-align: center;
  /* unfitted */
  border: var(--sklearn-color-unfitted-level-1) 1pt solid;
  color: var(--sklearn-color-unfitted-level-1);
}

.sk-estimator-doc-link.fitted,
a:link.sk-estimator-doc-link.fitted,
a:visited.sk-estimator-doc-link.fitted {
  /* fitted */
  border: var(--sklearn-color-fitted-level-1) 1pt solid;
  color: var(--sklearn-color-fitted-level-1);
}

/* On hover */
div.sk-estimator:hover .sk-estimator-doc-link:hover,
.sk-estimator-doc-link:hover,
div.sk-label-container:hover .sk-estimator-doc-link:hover,
.sk-estimator-doc-link:hover {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-3);
  color: var(--sklearn-color-background);
  text-decoration: none;
}

div.sk-estimator.fitted:hover .sk-estimator-doc-link.fitted:hover,
.sk-estimator-doc-link.fitted:hover,
div.sk-label-container:hover .sk-estimator-doc-link.fitted:hover,
.sk-estimator-doc-link.fitted:hover {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-3);
  color: var(--sklearn-color-background);
  text-decoration: none;
}

/* Span, style for the box shown on hovering the info icon */
.sk-estimator-doc-link span {
  display: none;
  z-index: 9999;
  position: relative;
  font-weight: normal;
  right: .2ex;
  padding: .5ex;
  margin: .5ex;
  width: min-content;
  min-width: 20ex;
  max-width: 50ex;
  color: var(--sklearn-color-text);
  box-shadow: 2pt 2pt 4pt #999;
  /* unfitted */
  background: var(--sklearn-color-unfitted-level-0);
  border: .5pt solid var(--sklearn-color-unfitted-level-3);
}

.sk-estimator-doc-link.fitted span {
  /* fitted */
  background: var(--sklearn-color-fitted-level-0);
  border: var(--sklearn-color-fitted-level-3);
}

.sk-estimator-doc-link:hover span {
  display: block;
}

/* "?"-specific style due to the `<a>` HTML tag */

#sk-container-id-1 a.estimator_doc_link {
  float: right;
  font-size: 1rem;
  line-height: 1em;
  font-family: monospace;
  background-color: var(--sklearn-color-background);
  border-radius: 1rem;
  height: 1rem;
  width: 1rem;
  text-decoration: none;
  /* unfitted */
  color: var(--sklearn-color-unfitted-level-1);
  border: var(--sklearn-color-unfitted-level-1) 1pt solid;
}

#sk-container-id-1 a.estimator_doc_link.fitted {
  /* fitted */
  border: var(--sklearn-color-fitted-level-1) 1pt solid;
  color: var(--sklearn-color-fitted-level-1);
}

/* On hover */
#sk-container-id-1 a.estimator_doc_link:hover {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-3);
  color: var(--sklearn-color-background);
  text-decoration: none;
}

#sk-container-id-1 a.estimator_doc_link.fitted:hover {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-3);
}

.estimator-table summary {
    padding: .5rem;
    font-family: monospace;
    cursor: pointer;
}

.estimator-table details[open] {
    padding-left: 0.1rem;
    padding-right: 0.1rem;
    padding-bottom: 0.3rem;
}

.estimator-table .parameters-table {
    margin-left: auto !important;
    margin-right: auto !important;
}

.estimator-table .parameters-table tr:nth-child(odd) {
    background-color: #fff;
}

.estimator-table .parameters-table tr:nth-child(even) {
    background-color: #f6f6f6;
}

.estimator-table .parameters-table tr:hover {
    background-color: #e0e0e0;
}

.estimator-table table td {
    border: 1px solid rgba(106, 105, 104, 0.232);
}

.user-set td {
    color:rgb(255, 94, 0);
    text-align: left;
}

.user-set td.value pre {
    color:rgb(255, 94, 0) !important;
    background-color: transparent !important;
}

.default td {
    color: black;
    text-align: left;
}

.user-set td i,
.default td i {
    color: black;
}

.copy-paste-icon {
    background-image: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCA0NDggNTEyIj48IS0tIUZvbnQgQXdlc29tZSBGcmVlIDYuNy4yIGJ5IEBmb250YXdlc29tZSAtIGh0dHBzOi8vZm9udGF3ZXNvbWUuY29tIExpY2Vuc2UgLSBodHRwczovL2ZvbnRhd2Vzb21lLmNvbS9saWNlbnNlL2ZyZWUgQ29weXJpZ2h0IDIwMjUgRm9udGljb25zLCBJbmMuLS0+PHBhdGggZD0iTTIwOCAwTDMzMi4xIDBjMTIuNyAwIDI0LjkgNS4xIDMzLjkgMTQuMWw2Ny45IDY3LjljOSA5IDE0LjEgMjEuMiAxNC4xIDMzLjlMNDQ4IDMzNmMwIDI2LjUtMjEuNSA0OC00OCA0OGwtMTkyIDBjLTI2LjUgMC00OC0yMS41LTQ4LTQ4bDAtMjg4YzAtMjYuNSAyMS41LTQ4IDQ4LTQ4ek00OCAxMjhsODAgMCAwIDY0LTY0IDAgMCAyNTYgMTkyIDAgMC0zMiA2NCAwIDAgNDhjMCAyNi41LTIxLjUgNDgtNDggNDhMNDggNTEyYy0yNi41IDAtNDgtMjEuNS00OC00OEwwIDE3NmMwLTI2LjUgMjEuNS00OCA0OC00OHoiLz48L3N2Zz4=);
    background-repeat: no-repeat;
    background-size: 14px 14px;
    background-position: 0;
    display: inline-block;
    width: 14px;
    height: 14px;
    cursor: pointer;
}
</style><body><div id="sk-container-id-1" class="sk-top-container"><div class="sk-text-repr-fallback"><pre>LinearRegression()</pre><b>In a Jupyter environment, please rerun this cell to show the HTML representation or trust the notebook. <br />On GitHub, the HTML representation is unable to render, please try loading this page with nbviewer.org.</b></div><div class="sk-container" hidden><div class="sk-item"><div class="sk-estimator fitted sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-1" type="checkbox" checked><label for="sk-estimator-id-1" class="sk-toggleable__label fitted sk-toggleable__label-arrow"><div><div>LinearRegression</div></div><div><a class="sk-estimator-doc-link fitted" rel="noreferrer" target="_blank" href="https://scikit-learn.org/1.7/modules/generated/sklearn.linear_model.LinearRegression.html">?<span>Documentation for LinearRegression</span></a><span class="sk-estimator-doc-link fitted">i<span>Fitted</span></span></div></label><div class="sk-toggleable__content fitted" data-param-prefix="">
        <div class="estimator-table">
            <details>
                <summary>Parameters</summary>
                <table class="parameters-table">
                  <tbody>

        <tr class="default">
            <td><i class="copy-paste-icon"
                 onclick="copyToClipboard('fit_intercept',
                          this.parentElement.nextElementSibling)"
            ></i></td>
            <td class="param">fit_intercept&nbsp;</td>
            <td class="value">True</td>
        </tr>


        <tr class="default">
            <td><i class="copy-paste-icon"
                 onclick="copyToClipboard('copy_X',
                          this.parentElement.nextElementSibling)"
            ></i></td>
            <td class="param">copy_X&nbsp;</td>
            <td class="value">True</td>
        </tr>


        <tr class="default">
            <td><i class="copy-paste-icon"
                 onclick="copyToClipboard('tol',
                          this.parentElement.nextElementSibling)"
            ></i></td>
            <td class="param">tol&nbsp;</td>
            <td class="value">1e-06</td>
        </tr>


        <tr class="default">
            <td><i class="copy-paste-icon"
                 onclick="copyToClipboard('n_jobs',
                          this.parentElement.nextElementSibling)"
            ></i></td>
            <td class="param">n_jobs&nbsp;</td>
            <td class="value">None</td>
        </tr>


        <tr class="default">
            <td><i class="copy-paste-icon"
                 onclick="copyToClipboard('positive',
                          this.parentElement.nextElementSibling)"
            ></i></td>
            <td class="param">positive&nbsp;</td>
            <td class="value">False</td>
        </tr>

                  </tbody>
                </table>
            </details>
        </div>
    </div></div></div></div></div><script>function copyToClipboard(text, element) {
    // Get the parameter prefix from the closest toggleable content
    const toggleableContent = element.closest('.sk-toggleable__content');
    const paramPrefix = toggleableContent ? toggleableContent.dataset.paramPrefix : '';
    const fullParamName = paramPrefix ? `${paramPrefix}${text}` : text;

    const originalStyle = element.style;
    const computedStyle = window.getComputedStyle(element);
    const originalWidth = computedStyle.width;
    const originalHTML = element.innerHTML.replace('Copied!', '');

    navigator.clipboard.writeText(fullParamName)
        .then(() => {
            element.style.width = originalWidth;
            element.style.color = 'green';
            element.innerHTML = "Copied!";

            setTimeout(() => {
                element.innerHTML = originalHTML;
                element.style = originalStyle;
            }, 2000);
        })
        .catch(err => {
            console.error('Failed to copy:', err);
            element.style.color = 'red';
            element.innerHTML = "Failed!";
            setTimeout(() => {
                element.innerHTML = originalHTML;
                element.style = originalStyle;
            }, 2000);
        });
    return false;
}

document.querySelectorAll('.fa-regular.fa-copy').forEach(function(element) {
    const toggleableContent = element.closest('.sk-toggleable__content');
    const paramPrefix = toggleableContent ? toggleableContent.dataset.paramPrefix : '';
    const paramName = element.parentElement.nextElementSibling.textContent.trim();
    const fullParamName = paramPrefix ? `${paramPrefix}${paramName}` : paramName;

    element.setAttribute('title', fullParamName);
});
</script></body>




```python
coef_df = pd.DataFrame({
    "Feature": x_train.columns,
    "Coefficient": lr.coef_
})

coef_df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Feature</th>
      <th>Coefficient</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>age</td>
      <td>248.210720</td>
    </tr>
    <tr>
      <th>1</th>
      <td>sex</td>
      <td>-101.542054</td>
    </tr>
    <tr>
      <th>2</th>
      <td>bmi</td>
      <td>318.701441</td>
    </tr>
    <tr>
      <th>3</th>
      <td>children</td>
      <td>533.009989</td>
    </tr>
    <tr>
      <th>4</th>
      <td>smoker</td>
      <td>23077.764593</td>
    </tr>
    <tr>
      <th>5</th>
      <td>region_northwest</td>
      <td>-391.761455</td>
    </tr>
    <tr>
      <th>6</th>
      <td>region_southeast</td>
      <td>-838.919616</td>
    </tr>
    <tr>
      <th>7</th>
      <td>region_southwest</td>
      <td>-659.139752</td>
    </tr>
  </tbody>
</table>
</div>




```python
y_pred=lr.predict(x_test)
```


```python
results=pd.DataFrame({"Actual":y_test,
                      "Prediction":y_pred})
results.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Actual</th>
      <th>Prediction</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>900</th>
      <td>8688.85885</td>
      <td>8143.693884</td>
    </tr>
    <tr>
      <th>1064</th>
      <td>5708.86700</td>
      <td>5737.115683</td>
    </tr>
    <tr>
      <th>1256</th>
      <td>11436.73815</td>
      <td>14369.314876</td>
    </tr>
    <tr>
      <th>298</th>
      <td>38746.35510</td>
      <td>31745.513636</td>
    </tr>
    <tr>
      <th>237</th>
      <td>4463.20510</td>
      <td>8962.386657</td>
    </tr>
  </tbody>
</table>
</div>




```python
from sklearn.metrics import (
    mean_absolute_error,
    mean_squared_error,
    r2_score
)
mae=mean_absolute_error(y_test,y_pred)
mse=mean_squared_error(y_test,y_pred)
rmse=np.sqrt(mse)
r2=r2_score(y_test,y_pred)
```


```python
print(f"MAE  : {mae:.2f}")
print(f"MSE  : {mse:.2f}")
print(f"RMSE : {rmse:.2f}")
print(f"R²   : {r2:.4f}")
```

    MAE  : 4177.05
    MSE  : 35478020.68
    RMSE : 5956.34
    R²   : 0.8069
    


```python
residuals=y_test-y_pred
```


```python
plt.figure(figsize=(8, 5))

sns.scatterplot(x=y_pred, y=residuals)

plt.axhline(y=0, color='red', linestyle='--')

plt.xlabel("Predicted Charges")
plt.ylabel("Residuals")
plt.title("Residuals vs Predicted Values")

plt.show()
```


    
![png](output_38_0.png)
    



```python
from scipy.stats import shapiro

stat, p = shapiro(residuals)

print("Shapiro-Wilk p-value:", p)
```

    Shapiro-Wilk p-value: 1.6968785669071645e-12
    


```python
plt.figure(figsize=(12,10))
sns.histplot(residuals)
```




    <Axes: xlabel='charges', ylabel='Count'>




    
![png](output_40_1.png)
    



```python
plt.figure(figsize=(6,6))
stats.probplot(residuals,dist='norm',plot=plt)
plt.title("Q-Q Plot of Residuals")
plt.show()
```


    
![png](output_41_0.png)
    



```python
from statsmodels.stats.outliers_influence import variance_inflation_factor

vif = pd.DataFrame()

vif["Feature"] = x_train.columns

vif["VIF"] = [
    variance_inflation_factor(x_train.values, i)
    for i in range(x_train.shape[1])
]

vif


```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Feature</th>
      <th>VIF</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>age</td>
      <td>7.852117</td>
    </tr>
    <tr>
      <th>1</th>
      <td>sex</td>
      <td>2.041788</td>
    </tr>
    <tr>
      <th>2</th>
      <td>bmi</td>
      <td>11.778800</td>
    </tr>
    <tr>
      <th>3</th>
      <td>children</td>
      <td>1.806171</td>
    </tr>
    <tr>
      <th>4</th>
      <td>smoker</td>
      <td>1.255160</td>
    </tr>
    <tr>
      <th>5</th>
      <td>region_northwest</td>
      <td>1.941491</td>
    </tr>
    <tr>
      <th>6</th>
      <td>region_southeast</td>
      <td>2.290072</td>
    </tr>
    <tr>
      <th>7</th>
      <td>region_southwest</td>
      <td>2.002452</td>
    </tr>
  </tbody>
</table>
</div>




```python
plt.figure(figsize=(8,6))
sns.heatmap(df.corr(numeric_only=True),
            annot=True,
            cmap='coolwarm',
            fmt='.2f')

plt.show()
```


    
![png](output_43_0.png)
    



```python

```
